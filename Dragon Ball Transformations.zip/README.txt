DRAGON BALL TRANSFORMATIONS 1.3

REQUIREMENTS:
-Dawnguard
-Dragonborn

FEATURES:
-12 powerful transformations from DBZ/DBS

TOOLS USED:
-LibXenoverse
-Blender
-Outfit Studio

RECOMMENDED MODS:
-DBZ Overhaul Post CK: https://www.nexusmods.com/skyrim/mods/12230
-Dragonball Z Overhaul Project: https://www.nexusmods.com/skyrim/mods/7847
-Dragon Ball and Naruto Spell Package: https://www.nexusmods.com/skyrim/mods/95419
-Dragon Ball Outfit(Goku's Outfit): https://www.nexusmods.com/skyrim/mods/7205 
-Flying Mod Beta: https://www.nexusmods.com/skyrim/mods/15775

CREDITS:
-Dragon Ball Xenoverse 2 (Models/textures)
-Dragon Ball Z Dokkan Battle (Zeni texture)
-Dragon Block C (Aura sounds)

DISCLAIMER:
I do not own the content used in the creation of this mod, I am using it in line with fair use as it is a transformative work.